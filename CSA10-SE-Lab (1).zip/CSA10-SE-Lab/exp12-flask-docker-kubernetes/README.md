# Experiment 12: Flask API -> Docker -> Docker Hub -> Kubernetes

| | |
|---|---|
| **Course** | CSA10 - Software Engineering |
| **CO** | CO3 |
| **Tools** | Docker & Kubernetes |
| **Evidence status** | REAL - unit tests / commands were actually executed; Docker/cloud steps need your own machine (see checklist) |

## Aim
Build a Flask API, containerise it, push to Docker Hub and deploy on Kubernetes (NodePort).

## Procedure
1. `app.py` with endpoints (tested below).
2. `docker build -t <user>/flask-api:1.0 .`
3. `docker login` then `docker push <user>/flask-api:1.0`
4. `kubectl apply -f k8s/deployment.yaml -f k8s/service.yaml`
5. `kubectl get pods,svc` then open `http://<node-ip>:30080` (Minikube: `minikube service flask-api-service --url`).

## Files in this folder
- `app.py`, `test_app.py`, `requirements.txt`, `Dockerfile`
- `k8s/deployment.yaml`, `k8s/service.yaml`
- `run_and_test.sh`, `output.txt`

## Program / Configuration
### `app.py`
```python
from flask import Flask, jsonify, request

app = Flask(__name__)
ITEMS = [{"id": 1, "name": "Learn Docker"}, {"id": 2, "name": "Learn Kubernetes"}]


@app.get("/")
def home():
    return jsonify(message="Hello from Flask on Kubernetes!", version="1.0")


@app.get("/health")
def health():
    return jsonify(status="ok")


@app.get("/api/greet/<name>")
def greet(name):
    return jsonify(greeting=f"Hello, {name}!")


@app.get("/api/items")
def list_items():
    return jsonify(ITEMS)


@app.post("/api/items")
def add_item():
    data = request.get_json(silent=True) or {}
    if "name" not in data:
        return jsonify(error="name is required"), 400
    item = {"id": len(ITEMS) + 1, "name": data["name"]}
    ITEMS.append(item)
    return jsonify(item), 201


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
```

### `Dockerfile`
```dockerfile
FROM python:3.12-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt
COPY app.py .
EXPOSE 5000
CMD ["python", "app.py"]
```

### `deployment.yaml`
```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: flask-api
  labels:
    app: flask-api
spec:
  replicas: 2
  selector:
    matchLabels:
      app: flask-api
  template:
    metadata:
      labels:
        app: flask-api
    spec:
      containers:
        - name: flask-api
          image: <dockerhub-username>/flask-api:1.0
          ports:
            - containerPort: 5000
          readinessProbe:
            httpGet:
              path: /health
              port: 5000
            initialDelaySeconds: 3
          resources:
            limits:
              cpu: "250m"
              memory: "128Mi"
```

### `service.yaml`
```yaml
apiVersion: v1
kind: Service
metadata:
  name: flask-api-service
spec:
  type: NodePort
  selector:
    app: flask-api
  ports:
    - port: 5000
      targetPort: 5000
      nodePort: 30080
```


## Output
**output**

![output.png](screenshots/output.png)

**yaml check**

![yaml_check.png](screenshots/yaml_check.png)

## Screenshots you still need to capture yourself
- [ ] Screenshots of `docker build`, `docker push` (Docker Hub repo page), `kubectl get pods,svc` and the API response through the NodePort. Replace `<dockerhub-username>` in the YAML first.

Put them in `screenshots/` and add a line to this README so the GitHub repo shows them.

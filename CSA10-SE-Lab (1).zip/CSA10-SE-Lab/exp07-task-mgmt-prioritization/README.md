# Experiment 7: Prioritise Task Management System Requirements (MoSCoW + Kano)

| | |
|---|---|
| **Course** | CSA10 - Software Engineering |
| **CO** | CO2 |
| **Tools** | Jira |
| **Evidence status** | ILLUSTRATION - generated drawing/sheet; replace with your own tool screenshot before submitting; the Excel file is REAL |

## Aim
Prioritise four requirements with MoSCoW and Kano in Jira.

## Procedure
1. Create project TMS; import `jira_import.csv` (map the two *Labels* columns to Labels).
2. Labels hold `MoSCoW-*` and `Kano-*`; set Priority from the MoSCoW result.
3. Create a filter/board grouped by label and screenshot it.

## Files in this folder
- `TMS_MoSCoW_Kano.xlsx`
- `jira_import.csv`
- `screenshots/`

## Output
**01 prioritization**

![01_prioritization.png](screenshots/01_prioritization.png)

## Screenshots you still need to capture yourself
- [ ] Screenshot of the Jira issue list/board showing the labels.

Put them in `screenshots/` and add a line to this README so the GitHub repo shows them.

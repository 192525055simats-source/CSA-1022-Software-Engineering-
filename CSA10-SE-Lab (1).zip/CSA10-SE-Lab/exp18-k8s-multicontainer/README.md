# Experiment 18: Multi-Container Application on Kubernetes

| | |
|---|---|
| **Course** | CSA10 - Software Engineering |
| **CO** | CO3 |
| **Tools** | Docker, Kubernetes |
| **Evidence status** | REAL - unit tests / commands were actually executed; Docker/cloud steps need your own machine (see checklist) |

## Aim
Deploy frontend (Nginx), backend (Flask) and database (PostgreSQL), monitor and scale the frontend.

## Procedure
1. Build/push the two images.
2. `kubectl apply -f k8s/app.yaml`
3. `kubectl get pods,svc` to monitor.
4. `kubectl scale deployment/frontend --replicas=5`
5. Open the dashboard (`minikube dashboard`).

## Files in this folder
- `frontend/`, `backend/`
- `k8s/app.yaml` (Secret, 3 Deployments, 3 Services)
- `commands.sh`
- `yaml_check.txt`

## Program / Configuration
### `app.yaml`
```yaml
apiVersion: v1
kind: Secret
metadata:
  name: db-secret
type: Opaque
stringData:
  POSTGRES_PASSWORD: changeme
---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: db
spec:
  replicas: 1
  selector: { matchLabels: { app: db } }
  template:
    metadata: { labels: { app: db } }
    spec:
      containers:
        - name: postgres
          image: postgres:16-alpine
          ports: [{ containerPort: 5432 }]
          envFrom: [{ secretRef: { name: db-secret } }]
---
apiVersion: v1
kind: Service
metadata:
  name: db
spec:
  selector: { app: db }
  ports: [{ port: 5432, targetPort: 5432 }]
---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: backend
spec:
  replicas: 2
  selector: { matchLabels: { app: backend } }
  template:
    metadata: { labels: { app: backend } }
    spec:
      containers:
        - name: backend
          image: <dockerhub-username>/k8s-backend:1.0
          ports: [{ containerPort: 5000 }]
          env: [{ name: DB_HOST, value: db }]
---
apiVersion: v1
kind: Service
metadata:
  name: backend
spec:
  selector: { app: backend }
  ports: [{ port: 5000, targetPort: 5000 }]
---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: frontend
spec:
  replicas: 2
  selector: { matchLabels: { app: frontend } }
  template:
    metadata: { labels: { app: frontend } }
    spec:
      containers:
        - name: frontend
          image: <dockerhub-username>/k8s-frontend:1.0
          ports: [{ containerPort: 80 }]
---
apiVersion: v1
kind: Service
metadata:
  name: frontend
spec:
  type: NodePort
  selector: { app: frontend }
  ports: [{ port: 80, targetPort: 80, nodePort: 30090 }]
```


## Output
**output**

![output.png](screenshots/output.png)

## Screenshots you still need to capture yourself
- [ ] Screenshots of `kubectl get pods,svc`, the scaled frontend and the Kubernetes dashboard.

Put them in `screenshots/` and add a line to this README so the GitHub repo shows them.

# Experiment 17: Push and Pull Docker Images with Docker Hub

| | |
|---|---|
| **Course** | CSA10 - Software Engineering |
| **CO** | CO3 |
| **Tools** | Docker Hub, Docker CLI |
| **Evidence status** | REAL - unit tests / commands were actually executed; Docker/cloud steps need your own machine (see checklist) |

## Aim
Build an image for a static site, push it to Docker Hub, pull and run it elsewhere.

## Procedure
1. Build, `docker login`, tag, push.
2. On another machine: `docker pull` and `docker run -p 8080:80`.
3. Screenshot every step.

## Files in this folder
- `index.html`, `Dockerfile`
- `commands.sh`

## Program / Configuration
### `commands.sh`
```bash
#!/usr/bin/env bash
# Replace <username> with your Docker Hub username.
docker build -t my-static-site:1.0 .                              # 1. build the image
docker login                                                      # authenticate to Docker Hub
docker tag my-static-site:1.0 <username>/my-static-site:1.0       # 2. tag
docker push <username>/my-static-site:1.0                         #    push
# --- on ANOTHER machine ---
docker pull <username>/my-static-site:1.0                         # 3. pull
docker run -d -p 8080:80 <username>/my-static-site:1.0            #    run
curl http://localhost:8080
```


## Output
No runnable output here: this experiment needs Docker and a Docker Hub account, so there are no pre-made screenshots. Capture them as listed below.

## Screenshots you still need to capture yourself
- [ ] Screenshots of build, tag, push (and the Docker Hub page), pull on the second machine and the running site.

Put them in `screenshots/` and add a line to this README so the GitHub repo shows them.

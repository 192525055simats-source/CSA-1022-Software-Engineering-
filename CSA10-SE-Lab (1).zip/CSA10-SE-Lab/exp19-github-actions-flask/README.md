# Experiment 19: CI/CD Pipeline for a Flask App with GitHub Actions

| | |
|---|---|
| **Course** | CSA10 - Software Engineering |
| **CO** | CO3 |
| **Tools** | GitHub Actions, Docker |
| **Evidence status** | REAL - unit tests / commands were actually executed; Docker/cloud steps need your own machine (see checklist) |

## Aim
Test, build, push to Docker Hub and deploy the Flask app to Heroku on every push.

## Procedure
1. Push this folder to a GitHub repo.
2. Add secrets `DOCKERHUB_USERNAME`, `DOCKERHUB_TOKEN`, `HEROKU_API_KEY`, `HEROKU_APP_NAME`.
3. Push a commit; watch *Actions*.
4. Submit the workflow file and the deployed URL.

## Files in this folder
- `.github/workflows/ci-cd.yml`
- `app.py`, `test_app.py`, `Dockerfile`

## Program / Configuration
### `ci-cd.yml`
```yaml
name: CI-CD Flask

on:
  push:
    branches: [main]
  pull_request:

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with:
          python-version: "3.12"
      - run: pip install -r requirements.txt
      - run: python -m unittest -v test_app.py

  build-and-push:
    needs: test
    if: github.ref == 'refs/heads/main'
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: docker/login-action@v3
        with:
          username: ${{ secrets.DOCKERHUB_USERNAME }}
          password: ${{ secrets.DOCKERHUB_TOKEN }}
      - uses: docker/build-push-action@v6
        with:
          context: .
          push: true
          tags: ${{ secrets.DOCKERHUB_USERNAME }}/flask-todo:latest

  deploy:
    needs: build-and-push
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Deploy container to Heroku
        env:
          HEROKU_API_KEY: ${{ secrets.HEROKU_API_KEY }}
          HEROKU_APP: ${{ secrets.HEROKU_APP_NAME }}
        run: |
          heroku container:login
          heroku container:push web -a $HEROKU_APP
          heroku container:release web -a $HEROKU_APP
```


## Output
**output**

![output.png](screenshots/output.png)

**yaml check**

![yaml_check.png](screenshots/yaml_check.png)

## Screenshots you still need to capture yourself
- [ ] Screenshot of the green run (test -> build-and-push -> deploy) and the deployed URL. Heroku is paid; you can swap the last job for AWS/Render.

Put them in `screenshots/` and add a line to this README so the GitHub repo shows them.

# Experiment 22: Commit and Push Changes

| | |
|---|---|
| **Course** | CSA10 - Software Engineering |
| **CO** | CO4 |
| **Tools** | Git/GitHub |
| **Evidence status** | REAL - produced by running the program in this repository (a local bare repo stands in for GitHub) |

## Aim
Commit a local change and push it to GitHub.

## Procedure
1. Modify README.md.
2. `git add`
3. `git commit -m "Updated README"`
4. `git push`.

## Files in this folder
- `commit_push.sh`
- `output.txt`

## Program / Configuration
### `commit_push.sh`
```bash
#!/usr/bin/env bash
# Experiment 22 - Commit changes locally and push to GitHub.
source "$(dirname "$0")/../common.sh"
cd "$WORK"
git init -q --bare -b main remote/demo.git
git clone -q remote/demo.git seed 2>/dev/null; cd seed
echo "# Demo" > README.md; git add .; git commit -qm "Initial commit"; git push -q origin main; cd ..
step "1. Clone the repository"
run git clone remote/demo.git; cd demo
step "2. Modify README.md"
echo "Updated for lab experiment 22." >> README.md; run cat README.md
step "3. Stage the changes"
run git add README.md; run git status
step '4. Commit with message "Updated README"'
run git commit -m "Updated README"
step "5. Push to GitHub"
run git push origin main
step "6. Verify local and remote are in sync"
run git log --oneline --decorate
run git status -sb
```


## Output
**output 1**

![output_1.png](screenshots/output_1.png)

**output 2**

![output_2.png](screenshots/output_2.png)

## Screenshots you still need to capture yourself
- [ ] Screenshot of the commit on GitHub.

Put them in `screenshots/` and add a line to this README so the GitHub repo shows them.

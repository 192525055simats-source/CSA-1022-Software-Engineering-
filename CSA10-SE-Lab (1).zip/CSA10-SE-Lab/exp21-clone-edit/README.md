# Experiment 21: Clone a Repository and Make a Small Change

| | |
|---|---|
| **Course** | CSA10 - Software Engineering |
| **CO** | CO3 |
| **Tools** | Git/GitHub |
| **Evidence status** | REAL - produced by running the program in this repository (a local bare repo stands in for GitHub) |

## Aim
Clone an existing repository and edit a file.

## Procedure
1. `git clone <url>`
2. `cd` and open a file.
3. Fix a typo and save.
4. `git diff` to show the change.

## Files in this folder
- `clone_edit.sh`
- `output.txt`

## Program / Configuration
### `clone_edit.sh`
```bash
#!/usr/bin/env bash
# Experiment 21 - Clone an existing repository and make a small change.
source "$(dirname "$0")/../common.sh"
cd "$WORK"
step "Setup: an existing public repository (stand-in for GitHub)"
git init -q --bare -b main remote/sample-repo.git
git clone -q remote/sample-repo.git seed 2>/dev/null; cd seed
printf "# Sample Repo\nThis repo is used for practcing git.\n" > README.md
git add . ; git commit -qm "Initial commit"; git push -q origin main; cd ..
step "1. Clone the repository"
run git clone remote/sample-repo.git
step "2. Navigate into the directory and open a file"
cd sample-repo; run ls -la; run cat README.md
step "3. Make a small edit (fix a typo: practcing -> practicing)"
run sed -i 's/practcing/practicing/' README.md
step "4. Save and view the change"
run git status --short
run git diff
```


## Output
**output**

![output.png](screenshots/output.png)


# Experiment 20: Create a GitHub Repository, Clone, Edit README, Push

| | |
|---|---|
| **Course** | CSA10 - Software Engineering |
| **CO** | CO3 |
| **Tools** | Git/GitHub |
| **Evidence status** | REAL - produced by running the program in this repository (a local bare repo stands in for GitHub) |

## Aim
Create a personal repository with a README, clone, edit and push.

## Procedure
1. Create repo with README.md.
2. `git clone`
3. Edit README.md.
4. `git add`, `git commit`, `git push`.

## Files in this folder
- `create_repo.sh`
- `output.txt`

## Program / Configuration
### `create_repo.sh`
```bash
#!/usr/bin/env bash
# Experiment 20 - Create a GitHub repository, clone it, edit README.md, push.
source "$(dirname "$0")/../common.sh"
cd "$WORK"
step "1. Create the repository (GitHub stand-in) with an initial README.md"
run git init --bare -b main remote/personal-project.git
run git clone remote/personal-project.git web-ui
cd web-ui; echo "# personal-project" > README.md
run git add README.md; run git commit -m "Initial commit"; run git push -u origin main
cd ..
step "2. Clone the repository to the local machine"
run git clone remote/personal-project.git personal-project
cd personal-project
step "3. Edit README.md (add a project description)"
cat >> README.md <<'T'

## Description
Personal project created for CSA10 Software Engineering lab.
It demonstrates the basic Git workflow: clone, edit, commit and push.
T
run cat README.md
step "4. Stage, commit and push"
run git status --short
run git add README.md
run git commit -m "Add project description to README"
run git push origin main
step "5. Verify"
run git log --oneline
run git status -sb
```


## Output
**output 1**

![output_1.png](screenshots/output_1.png)

**output 2**

![output_2.png](screenshots/output_2.png)

## Screenshots you still need to capture yourself
- [ ] Screenshot of your real GitHub repository page after the push.

Put them in `screenshots/` and add a line to this README so the GitHub repo shows them.

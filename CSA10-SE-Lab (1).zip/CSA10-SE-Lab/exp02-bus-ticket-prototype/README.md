# Experiment 2: Prototype of a Bus Ticket Booking System

| | |
|---|---|
| **Course** | CSA10 - Software Engineering |
| **CO** | CO1 |
| **Tools** | Figma |
| **Evidence status** | ILLUSTRATION - generated drawing/sheet; replace with your own tool screenshot before submitting |

## Aim
Sketch a simple prototype of a bus ticket booking system in Figma.

## Procedure
1. Open Figma -> new Design file; add four *Frames* (360x640): Search, Bus list, Seat selection, Confirmation.
2. Use rectangles, text and the Auto Layout feature to build inputs, bus cards, seat grid and buttons.
3. Open the *Prototype* tab and connect Search Button -> Bus list -> Select -> Seat selection -> Continue -> Confirmation (On click, Navigate to).
4. Press *Present* to test the flow; export frames as PNG.

## Files in this folder
- `screenshots/01_bus_ticket_prototype.png` - the four-screen flow

## Output
**01 bus ticket prototype**

![01_bus_ticket_prototype.png](screenshots/01_bus_ticket_prototype.png)

## Screenshots you still need to capture yourself
- [ ] Screenshot of your Figma file (frames + prototype arrows) and the Figma share link.

Put them in `screenshots/` and add a line to this README so the GitHub repo shows them.

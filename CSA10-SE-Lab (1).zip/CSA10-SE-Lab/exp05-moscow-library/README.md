# Experiment 5: MoSCoW Prioritisation - Library Management System

| | |
|---|---|
| **Course** | CSA10 - Software Engineering |
| **CO** | CO2 |
| **Tools** | Google Sheet / Excel |
| **Evidence status** | REAL FILE - the Excel workbook is the deliverable; screenshot is a rendering of it |

## Aim
Categorise 10 requirements as Must/Should/Could/Won't based on impact and feasibility, with justification.

## Procedure
1. List the 10 requirements in a sheet.
2. Rate each for *impact on users/stakeholders* and *feasibility* (time, budget, resources).
3. Assign MoSCoW category and write a justification.
4. Colour code the category column and submit the file.

## Files in this folder
- `LMS_MoSCoW_Prioritization.xlsx` - **submit this file**
- `screenshots/`

## Notes
**Result:** 3 Must-Have, 2 Should-Have, 3 Could-Have, 2 Won't-Have (this release).

## Output
**01 moscow sheet**

![01_moscow_sheet.png](screenshots/01_moscow_sheet.png)

**02 summary**

![02_summary.png](screenshots/02_summary.png)


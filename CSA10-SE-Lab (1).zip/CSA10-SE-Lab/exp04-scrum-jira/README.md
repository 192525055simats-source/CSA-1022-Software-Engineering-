# Experiment 4: Scrum Project in Jira (Backlog, 1-week Sprint)

| | |
|---|---|
| **Course** | CSA10 - Software Engineering |
| **CO** | CO2 |
| **Tools** | Jira |
| **Evidence status** | ILLUSTRATION - generated drawing/sheet; replace with your own tool screenshot before submitting; the Python sprint simulation output is REAL |

## Aim
Create a Scrum project, add a backlog of 5+ items, prioritise, run a 1-week sprint and show the board at start and end.

## Procedure
1. Jira -> Create project -> *Scrum* template -> name *SHOP*.
2. Backlog -> create issues (or import `jira_backlog_import.csv`).
3. Drag issues to order by priority (highest at the top).
4. Create Sprint -> drag 5 issues in -> Start Sprint (duration 1 week). Screenshot the board.
5. Move cards across the board during the week; Complete Sprint at the end. Screenshot the board.

## Files in this folder
- `sprint_sim.py` - sprint/burndown model
- `jira_backlog_import.csv`
- `screenshots/`

## Program / Configuration
### `sprint_sim.py`
```python
"""Exp 4 - Model a 1-week Scrum sprint: prioritised backlog -> sprint -> burndown."""
backlog = [  # (key, summary, story points, priority)
    ("SHOP-1", "Create user registration page", 3, "High"),
    ("SHOP-2", "Develop API for login", 5, "Highest"),
    ("SHOP-3", "Design product listing page", 3, "Medium"),
    ("SHOP-4", "Implement shopping cart", 5, "High"),
    ("SHOP-5", "Integrate payment gateway", 8, "Medium"),
    ("SHOP-6", "Write unit tests for login API", 2, "Low"),
]
order = {"Highest": 0, "High": 1, "Medium": 2, "Low": 3}
backlog.sort(key=lambda x: order[x[3]])
print("Prioritised backlog")
for k, s, p, pr in backlog:
    print(f"  {k:7}{pr:8}{p:>2} pts  {s}")
sprint = [i for i in backlog if i[0] != "SHOP-5"]   # capacity ~ 18 points
total = sum(i[2] for i in sprint)
print(f"\nSprint 1 (Mon-Fri) scope: {len(sprint)} issues, {total} story points")
done_per_day = {"Mon": 0, "Tue": 5, "Wed": 3, "Thu": 5, "Fri": 5}
remaining = total
print("\nDay  Completed  Remaining  Burndown")
for day, d in done_per_day.items():
    remaining -= d
    print(f"{day}  {d:>9}  {remaining:>9}  {'#' * remaining}")
print("\nSprint completed: all committed issues Done" if remaining == 0 else f"\nCarry-over: {remaining} points")
```


## Output
**01 backlog prioritised**

![01_backlog_prioritised.png](screenshots/01_backlog_prioritised.png)

**02 sprint board start**

![02_sprint_board_start.png](screenshots/02_sprint_board_start.png)

**03 sprint board end**

![03_sprint_board_end.png](screenshots/03_sprint_board_end.png)

**output**

![output.png](screenshots/output.png)

## Screenshots you still need to capture yourself
- [ ] Screenshots of your Jira sprint board at the start and the end.

Put them in `screenshots/` and add a line to this README so the GitHub repo shows them.

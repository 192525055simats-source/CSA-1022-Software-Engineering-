# Experiment 13: CI/CD Pipeline with Jenkins

| | |
|---|---|
| **Course** | CSA10 - Software Engineering |
| **CO** | CO4 |
| **Tools** | Jenkins, Docker |
| **Evidence status** | REAL - unit tests / commands were actually executed; Docker/cloud steps need your own machine (see checklist) |

## Aim
Automate build, test and deploy of a containerised app with Jenkins.

## Procedure
1. Install Jenkins (e.g. `docker run -p 8080:8080 jenkins/jenkins:lts`), add plugins Docker Pipeline and Git.
2. Add credentials `dockerhub` and `aws-creds`.
3. Create a *Pipeline* job -> *Pipeline script from SCM* -> this repo.
4. GitHub repo -> Settings -> Webhooks -> `http://<jenkins>/github-webhook/` so commits trigger builds.
5. Push a commit and watch the stages.

## Files in this folder
- `Jenkinsfile`
- `Dockerfile`
- `sample-app/`

## Program / Configuration
### `Jenkinsfile`
```groovy
pipeline {
    agent any
    environment {
        IMAGE      = "<dockerhub-username>/flask-api"
        TAG        = "${env.BUILD_NUMBER}"
        AWS_REGION = "ap-south-1"
    }
    triggers { pollSCM('H/2 * * * *') }   // fallback; the GitHub webhook triggers builds instantly
    stages {
        stage('Checkout') {
            steps { checkout scm }
        }
        stage('Build Image') {
            steps { sh 'docker build -t $IMAGE:$TAG sample-app' }
        }
        stage('Test') {
            steps { sh 'docker run --rm $IMAGE:$TAG python -m unittest -v test_app.py' }
        }
        stage('Push Image') {
            steps {
                withCredentials([usernamePassword(credentialsId: 'dockerhub', usernameVariable: 'U', passwordVariable: 'P')]) {
                    sh 'echo $P | docker login -u $U --password-stdin && docker push $IMAGE:$TAG'
                }
            }
        }
        stage('Deploy') {
            steps {
                withCredentials([[$class: 'AmazonWebServicesCredentialsBinding', credentialsId: 'aws-creds']]) {
                    sh '''
                      aws ecs update-service --cluster flask-cluster --service flask-service \
                          --force-new-deployment --region $AWS_REGION
                    '''
                }
            }
        }
    }
    post {
        success { echo "Build ${env.BUILD_NUMBER} deployed" }
        failure { echo "Build ${env.BUILD_NUMBER} failed" }
    }
}
```


## Output
**output**

![output.png](screenshots/output.png)

## Screenshots you still need to capture yourself
- [ ] Screenshots of the Jenkins stage view (all green), console output and the webhook delivery in GitHub.

Put them in `screenshots/` and add a line to this README so the GitHub repo shows them.

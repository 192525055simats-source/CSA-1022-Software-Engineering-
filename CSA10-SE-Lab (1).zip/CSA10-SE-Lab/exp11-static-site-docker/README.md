# Experiment 11: Static Website with Nginx in Docker

| | |
|---|---|
| **Course** | CSA10 - Software Engineering |
| **CO** | CO3 |
| **Tools** | Docker |
| **Evidence status** | REAL - unit tests / commands were actually executed; Docker/cloud steps need your own machine (see checklist) |

## Aim
Create a static website, containerise it with Nginx, build, run and browse it.

## Procedure
1. Create `index.html`.
2. Write the `Dockerfile` (nginx:alpine).
3. `docker build -t static-site:1.0 .`
4. `docker run -d -p 8080:80 static-site:1.0`
5. Open http://localhost:8080.

## Files in this folder
- `index.html`
- `Dockerfile`
- `commands.sh`
- `serve_preview.sh` / `output.txt`

## Program / Configuration
### `Dockerfile`
```dockerfile
FROM nginx:alpine
COPY index.html /usr/share/nginx/html/index.html
EXPOSE 80
```


## Output
**output**

![output.png](screenshots/output.png)

## Screenshots you still need to capture yourself
- [ ] On a machine with Docker: screenshots of `docker build`, `docker images`, `docker ps` and the browser showing the page.

Put them in `screenshots/` and add a line to this README so the GitHub repo shows them.

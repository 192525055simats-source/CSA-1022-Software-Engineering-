# Experiment 6: Link Jira with Confluence - Project Overview Page

| | |
|---|---|
| **Course** | CSA10 - Software Engineering |
| **CO** | CO2 |
| **Tools** | Jira & Confluence |
| **Evidence status** | ILLUSTRATION - generated drawing/sheet; replace with your own tool screenshot before submitting; the progress calculation output is REAL |

## Aim
Create the Confluence page 'Library Management System Project Overview', embed 5+ Jira issues with the Jira macro and add a progress bar.

## Procedure
1. Confluence -> Create -> Page -> title *Library Management System Project Overview*.
2. Type `/jira` -> *Jira issues* macro -> paste a JQL such as `project = LMS AND sprint in openSprints()`; display columns Key, Summary, Status.
3. Add a status/progress section: use the *Jira Chart* macro (Pie/Status) or the *Progress/Status* lozenges; percentages computed as in `progress_bar.py`.
4. Publish and take a screenshot.

## Files in this folder
- `progress_bar.py`
- `screenshots/`

## Program / Configuration
### `progress_bar.py`
```python
"""Exp 6 - Compute the completion percentages shown on the Confluence progress bar."""
issues = [
    ("LMS-1", "Develop book search functionality", "Done"),
    ("LMS-2", "Create user login page", "Done"),
    ("LMS-3", "Implement book reservation", "In Progress"),
    ("LMS-4", "Generate monthly borrowed-book report", "In Progress"),
    ("LMS-5", "Send overdue email notifications", "To Do"),
    ("LMS-6", "Build librarian dashboard", "To Do"),
]
weight = {"Done": 100, "In Progress": 50, "To Do": 0}


def bar(pct, n=30):
    full = round(n * pct / 100)
    return "[" + "#" * full + "." * (n - full) + f"] {pct:3.0f}%"


for k, s, st in issues:
    print(f"{k:6} {s:40} {st:12} {bar(weight[st], 20)}")
done = sum(1 for _, _, st in issues if st == "Done")
print(f"\nIssues done: {done}/{len(issues)}")
print("Sprint completion (issues):", bar(100 * done / len(issues)))
print("Weighted progress         :", bar(sum(weight[st] for *_, st in issues) / len(issues)))
```


## Output
**01 confluence page**

![01_confluence_page.png](screenshots/01_confluence_page.png)

**output**

![output.png](screenshots/output.png)

## Screenshots you still need to capture yourself
- [ ] Screenshot of your Confluence page with the Jira macro table and progress section.

Put them in `screenshots/` and add a line to this README so the GitHub repo shows them.

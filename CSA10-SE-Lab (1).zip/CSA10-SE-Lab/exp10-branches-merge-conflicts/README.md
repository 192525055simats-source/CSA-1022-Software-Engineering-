# Experiment 10: Git Branches and Resolving Merge Conflicts

| | |
|---|---|
| **Course** | CSA10 - Software Engineering |
| **CO** | CO3 |
| **Tools** | Git/GitHub |
| **Evidence status** | REAL - produced by running the program in this repository (a local bare repo stands in for GitHub) |

## Aim
Work with branches and resolve a real merge conflict.

## Procedure
1. Clone, branch, change, commit, push.
2. Collaborator changes the same line on `main`.
3. Merge `main` into the feature branch -> conflict -> edit the file, `git add`, commit.
4. Push and open a pull request.

## Files in this folder
- `merge_conflict.sh`
- `output.txt`
- `screenshots/`

## Program / Configuration
### `merge_conflict.sh`
```bash
#!/usr/bin/env bash
# Experiment 10 - Branches and resolving merge conflicts.
source "$(dirname "$0")/../common.sh"
cd "$WORK"
git init -q --bare -b main remote/shared.git
git clone -q remote/shared.git seed 2>/dev/null; cd seed
printf "# Shared Project\n" > README.md
printf 'def greet():\n    return "Hello"\n' > app.py
git add .; git commit -qm "Initial commit"; git push -q origin main; cd ..
step "1. Clone the shared repository"
run git clone remote/shared.git me; cd me
step "2. Create and switch to a new branch"
run git checkout -b feature-greeting
step "3-4. Change greet() and commit"
printf 'def greet():\n    return "Hello, Roobini!"\n' > app.py
run git commit -am "Personalise greeting"
step "5. Push the branch"
run git push -u origin feature-greeting
step "(meanwhile) Collaborator changes the SAME line on main and pushes"
cd "$WORK"; git clone -q remote/shared.git collab 2>/dev/null; cd collab
printf 'def greet():\n    return "Welcome"\n' > app.py
as_collab git commit -qam "Change greeting to Welcome"; git push -q origin main
echo '$ (collaborator) git commit -am "Change greeting to Welcome" && git push origin main'
cd "$WORK/me"
step "6-7. Pull latest main, switch back to feature branch"
run git fetch origin
run git checkout feature-greeting
step "8. Merge main into the feature branch -> CONFLICT"
echo '$ git merge origin/main'; git merge origin/main 2>&1 || true
run git status --short
step "9. Open the conflicting file and resolve manually"
run cat app.py
printf 'def greet():\n    return "Welcome, Roobini!"\n' > app.py
echo '(edited by hand: kept both ideas -> "Welcome, Roobini!")'
run cat app.py
run git add app.py
step "10. Commit the resolved merge"
run git commit -m "Merge main into feature-greeting; resolve greeting conflict"
step "11. Push the merged branch (then open a pull request on GitHub)"
run git push origin feature-greeting
run git log --oneline --graph --decorate
```


## Notes
**Conflict encountered:** both branches edited the `return` line of `greet()` in `app.py`. **Resolution:** kept both ideas (`Welcome, Roobini!`).

## Output
**output 1**

![output_1.png](screenshots/output_1.png)

**output 2**

![output_2.png](screenshots/output_2.png)

**output 3**

![output_3.png](screenshots/output_3.png)

## Screenshots you still need to capture yourself
- [ ] Optional: screenshot of GitHub's PR page for the branch.

Put them in `screenshots/` and add a line to this README so the GitHub repo shows them.

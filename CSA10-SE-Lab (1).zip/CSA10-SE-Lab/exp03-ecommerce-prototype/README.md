# Experiment 3: E-Commerce App Prototype for Conflicting Stakeholder Views

| | |
|---|---|
| **Course** | CSA10 - Software Engineering |
| **CO** | CO1 |
| **Tools** | Figma |
| **Evidence status** | ILLUSTRATION - generated drawing/sheet; replace with your own tool screenshot before submitting |

## Aim
Stakeholders disagree on the UI of an e-commerce app. Build prototypes of the competing views, gather feedback and reach approval.

## Procedure
1. Interview stakeholders and record each viewpoint (Marketing: image-heavy grid; Operations: detailed list).
2. In Figma create Option A (grid) and Option B (list) on separate pages.
3. Share the prototype link with *comment* access; collect feedback with Figma comments.
4. Create a Final design combining the strengths (grid default + list toggle, rating/delivery shown on each card).
5. Present the Final prototype and record approval in the feedback log.

## Files in this folder
- `screenshots/01_design_options.png`
- `screenshots/02_feedback_log.png`

## Output
**01 design options**

![01_design_options.png](screenshots/01_design_options.png)

**02 feedback log**

![02_feedback_log.png](screenshots/02_feedback_log.png)

## Screenshots you still need to capture yourself
- [ ] Screenshot of your Figma pages with comments, plus the share link.

Put them in `screenshots/` and add a line to this README so the GitHub repo shows them.

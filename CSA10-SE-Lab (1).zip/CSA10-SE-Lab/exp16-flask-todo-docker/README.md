# Experiment 16: Containerise a Flask To-Do App

| | |
|---|---|
| **Course** | CSA10 - Software Engineering |
| **CO** | CO3 |
| **Tools** | Docker, Flask |
| **Evidence status** | REAL - unit tests / commands were actually executed; Docker/cloud steps need your own machine (see checklist) |

## Aim
Write a Flask To-Do API, containerise, run, test, and push to Docker Hub.

## Procedure
1. `docker build -t todo-app:1.0 .`
2. `docker run -d -p 5000:5000 todo-app:1.0`
3. Test with `curl` (see output) inside/against the container.
4. `docker tag todo-app:1.0 <user>/todo-app:1.0 && docker push <user>/todo-app:1.0`

## Files in this folder
- `app.py`, `test_app.py`, `Dockerfile`, `requirements.txt`
- `run_and_test.sh`, `output.txt`

## Program / Configuration
### `app.py`
```python
from flask import Flask, jsonify, request

app = Flask(__name__)
todos = []
next_id = 1


@app.get("/")
def index():
    return jsonify(app="To-Do List API", endpoints=["/todos", "/todos/<id>"])


@app.get("/todos")
def list_todos():
    return jsonify(todos)


@app.post("/todos")
def create_todo():
    global next_id
    data = request.get_json(silent=True) or {}
    if not data.get("title"):
        return jsonify(error="title is required"), 400
    todo = {"id": next_id, "title": data["title"], "done": False}
    next_id += 1
    todos.append(todo)
    return jsonify(todo), 201


@app.put("/todos/<int:todo_id>")
def update_todo(todo_id):
    for t in todos:
        if t["id"] == todo_id:
            data = request.get_json(silent=True) or {}
            t["title"] = data.get("title", t["title"])
            t["done"] = data.get("done", t["done"])
            return jsonify(t)
    return jsonify(error="not found"), 404


@app.delete("/todos/<int:todo_id>")
def delete_todo(todo_id):
    global todos
    before = len(todos)
    todos = [t for t in todos if t["id"] != todo_id]
    if len(todos) == before:
        return jsonify(error="not found"), 404
    return "", 204


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
```

### `Dockerfile`
```dockerfile
FROM python:3.12-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt
COPY app.py .
EXPOSE 5000
CMD ["python", "app.py"]
```


## Output
**output**

![output.png](screenshots/output.png)

## Screenshots you still need to capture yourself
- [ ] Screenshots of `docker build/run`, the same curl calls against the container and the Docker Hub repository page.

Put them in `screenshots/` and add a line to this README so the GitHub repo shows them.

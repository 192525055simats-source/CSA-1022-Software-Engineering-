# Experiment 1: Kanban Board to Visualise Tasks

| | |
|---|---|
| **Course** | CSA10 - Software Engineering |
| **CO** | CO1 |
| **Tools** | Jira or Trello |
| **Evidence status** | ILLUSTRATION - generated drawing/sheet; replace with your own tool screenshot before submitting; the Python simulation output is REAL |

## Aim
Create a Kanban board with To Do / In Progress / Done columns, add at least 5 tasks and move them across the columns.

## Procedure
1. Trello: Create board -> add lists *To Do*, *In Progress*, *Done*. (Jira: Create project -> Kanban template.)
2. Add 6 cards (tasks) from `kanban_tasks.csv` to *To Do* (CSV can be imported into Jira).
3. Drag two cards to *In Progress*, then one to *Done* (stage 2).
4. Continue moving cards to simulate the workflow (stage 3, final).
5. Take a screenshot at each stage.

## Files in this folder
- `kanban_sim.py` - Python simulation of the board
- `kanban_tasks.csv` - tasks for Jira import
- `screenshots/` - board at three stages, program output

## Program / Configuration
### `kanban_sim.py`
```python
"""Exp 1 - Simulate a Kanban board (To Do / In Progress / Done) and move tasks across columns."""
COLUMNS = ["To Do", "In Progress", "Done"]
board = {c: [] for c in COLUMNS}
for t in ["Design login page", "Create database schema", "Write API documentation",
          "Implement search feature", "Set up CI pipeline", "Test payment module"]:
    board["To Do"].append(t)


def show(title):
    print(f"\n=== {title} ===")
    width = 26
    print(" | ".join(c.ljust(width) for c in COLUMNS))
    print("-+-".join("-" * width for _ in COLUMNS))
    for i in range(max(len(v) for v in board.values())):
        print(" | ".join((board[c][i] if i < len(board[c]) else "").ljust(width) for c in COLUMNS))


def move(task, src, dst):
    board[src].remove(task)
    board[dst].append(task)
    print(f"moved '{task}': {src} -> {dst}")


show("Initial board")
move("Design login page", "To Do", "In Progress")
move("Create database schema", "To Do", "In Progress")
show("After starting work")
move("Design login page", "In Progress", "Done")
move("Set up CI pipeline", "To Do", "In Progress")
move("Set up CI pipeline", "In Progress", "Done")
show("Final board")
print("\nWIP:", len(board["In Progress"]), "| Done:", len(board["Done"]), "| Remaining:", len(board["To Do"]))
```


## Output
**01 board initial**

![01_board_initial.png](screenshots/01_board_initial.png)

**02 board in progress**

![02_board_in_progress.png](screenshots/02_board_in_progress.png)

**03 board final**

![03_board_final.png](screenshots/03_board_final.png)

**output**

![output.png](screenshots/output.png)

## Screenshots you still need to capture yourself
- [ ] Screenshots of your real Trello/Jira board at the 3 stages.

Put them in `screenshots/` and add a line to this README so the GitHub repo shows them.

# Experiment 8: Prioritise Online Learning Platform Requirements (MoSCoW + Kano)

| | |
|---|---|
| **Course** | CSA10 - Software Engineering |
| **CO** | CO2 |
| **Tools** | Jira |
| **Evidence status** | ILLUSTRATION - generated drawing/sheet; replace with your own tool screenshot before submitting; the Excel file is REAL |

## Aim
Categorise six platform functionalities with MoSCoW and Kano in Jira.

## Procedure
1. Create project OLP; import `jira_import.csv`.
2. Verify labels `MoSCoW-*` and `Kano-*` on each issue.
3. Sort by Priority and screenshot the result.

## Files in this folder
- `OLP_MoSCoW_Kano.xlsx`
- `jira_import.csv`
- `screenshots/`

## Output
**01 prioritization**

![01_prioritization.png](screenshots/01_prioritization.png)

## Screenshots you still need to capture yourself
- [ ] Screenshot of the Jira issue list showing the labels.

Put them in `screenshots/` and add a line to this README so the GitHub repo shows them.

# CSA10 - Software Engineering Lab Record

**Name:** Roobini P | **Reg. No.:** 192525055 | Saveetha School of Engineering, Department of Computer Science Engineering

One folder per experiment from the *CSA10 List of Lab Experiments*. Each folder has a `README.md` (aim, procedure, program, output screenshots), the program/config files and a `screenshots/` folder.

## Evidence legend (please read before submitting)
- **Real run** - the script in the folder was executed and the screenshot is a rendering of its actual output. The Git experiments use a local bare repository in place of github.com so they run offline; replace the remote URL with your own GitHub repository to reproduce them on GitHub and take real screenshots of the PR pages.
- **Real tests + capture needed** - code/config is complete and the tests were executed locally, but Docker, Kubernetes, Jenkins, and cloud deployment were not available here. Run the commands in the README and capture those screenshots yourself.
- **Illustration + capture needed** - Jira, Trello, Figma and Confluence cannot be driven from here. The drawn boards/wireframes show the expected result and are labelled as generated; replace them with real screenshots from your accounts. The Excel files (Exp 5, 7, 8) and CSV import files are real.

## Experiments
| # | Experiment | Tools | CO | Evidence |
|---|---|---|---|---|
| 1 | [Kanban Board to Visualise Tasks](exp01-kanban-board/README.md) | Jira or Trello | CO1 | Illustration + capture needed |
| 2 | [Prototype of a Bus Ticket Booking System](exp02-bus-ticket-prototype/README.md) | Figma | CO1 | Illustration + capture needed |
| 3 | [E-Commerce App Prototype for Conflicting Stakeholder Views](exp03-ecommerce-prototype/README.md) | Figma | CO1 | Illustration + capture needed |
| 4 | [Scrum Project in Jira (Backlog, 1-week Sprint)](exp04-scrum-jira/README.md) | Jira | CO2 | Illustration + capture needed |
| 5 | [MoSCoW Prioritisation - Library Management System](exp05-moscow-library/README.md) | Google Sheet / Excel | CO2 | Real file |
| 6 | [Link Jira with Confluence - Project Overview Page](exp06-jira-confluence/README.md) | Jira & Confluence | CO2 | Illustration + capture needed |
| 7 | [Prioritise Task Management System Requirements (MoSCoW + Kano)](exp07-task-mgmt-prioritization/README.md) | Jira | CO2 | Illustration + capture needed |
| 8 | [Prioritise Online Learning Platform Requirements (MoSCoW + Kano)](exp08-online-learning-prioritization/README.md) | Jira | CO2 | Illustration + capture needed |
| 9 | [Fork-and-Pull-Request Workflow](exp09-fork-pull-request/README.md) | Git/GitHub | CO3 | Real run |
| 10 | [Git Branches and Resolving Merge Conflicts](exp10-branches-merge-conflicts/README.md) | Git/GitHub | CO3 | Real run |
| 11 | [Static Website with Nginx in Docker](exp11-static-site-docker/README.md) | Docker | CO3 | Real tests + capture needed |
| 12 | [Flask API -> Docker -> Docker Hub -> Kubernetes](exp12-flask-docker-kubernetes/README.md) | Docker & Kubernetes | CO3 | Real tests + capture needed |
| 13 | [CI/CD Pipeline with Jenkins](exp13-jenkins-cicd/README.md) | Jenkins, Docker | CO4 | Real tests + capture needed |
| 14 | [Continuous Deployment with GitHub Actions](exp14-github-actions-cd/README.md) | GitHub Actions, Docker | CO4 | Real tests + capture needed |
| 15 | [Team Repository with Branches, Pull Requests and Conflicts](exp15-github-team-repo/README.md) | Git/GitHub | CO3 | Real run |
| 16 | [Containerise a Flask To-Do App](exp16-flask-todo-docker/README.md) | Docker, Flask | CO3 | Real tests + capture needed |
| 17 | [Push and Pull Docker Images with Docker Hub](exp17-dockerhub-push-pull/README.md) | Docker Hub, Docker CLI | CO3 | Real tests + capture needed |
| 18 | [Multi-Container Application on Kubernetes](exp18-k8s-multicontainer/README.md) | Docker, Kubernetes | CO3 | Real tests + capture needed |
| 19 | [CI/CD Pipeline for a Flask App with GitHub Actions](exp19-github-actions-flask/README.md) | GitHub Actions, Docker | CO3 | Real tests + capture needed |
| 20 | [Create a GitHub Repository, Clone, Edit README, Push](exp20-create-repo/README.md) | Git/GitHub | CO3 | Real run |
| 21 | [Clone a Repository and Make a Small Change](exp21-clone-edit/README.md) | Git/GitHub | CO3 | Real run |
| 22 | [Commit and Push Changes](exp22-commit-push/README.md) | Git/GitHub | CO4 | Real run |
| 23 | [Pull the Latest Changes from GitHub](exp23-pull-changes/README.md) | Git/GitHub | CO4 | Real run |
| 24 | [Feature Branch `feature-login` with Pull Request](exp24-feature-login-pr/README.md) | Git/GitHub | CO4 | Real run |
| 25 | [Fork, Fetch Upstream, Feature Branch and Pull Request](exp25-fork-feature-pr/README.md) | Git/GitHub | CO4 | Real run |

## Publishing this folder to GitHub
```bash
cd CSA10-SE-Lab
git init -b main
git add .
git commit -m "Add CSA10 lab experiments"
git remote add origin https://github.com/<your-username>/CSA10-SE-Lab.git
git push -u origin main
```

## Running the scripts
`bash expNN-*/<script>.sh` (needs `git`, `python3`; Flask experiments need `pip install flask`).

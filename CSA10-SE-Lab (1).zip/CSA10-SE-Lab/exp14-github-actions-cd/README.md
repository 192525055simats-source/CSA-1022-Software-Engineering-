# Experiment 14: Continuous Deployment with GitHub Actions

| | |
|---|---|
| **Course** | CSA10 - Software Engineering |
| **CO** | CO4 |
| **Tools** | GitHub Actions, Docker |
| **Evidence status** | REAL - unit tests / commands were actually executed; Docker/cloud steps need your own machine (see checklist) |

## Aim
Build and push a Docker image on every push to `main` and deploy it to AWS ECS.

## Procedure
1. Push `app/` and `.github/workflows/cd.yml` to a GitHub repo.
2. Add repository secrets `AWS_ACCESS_KEY_ID`, `AWS_SECRET_ACCESS_KEY`.
3. Push a code change; open the *Actions* tab.
4. Verify the image in GHCR (*Packages*) and the new ECS deployment.

## Files in this folder
- `.github/workflows/cd.yml`
- `app/`

## Program / Configuration
### `cd.yml`
```yaml
name: Continuous Deployment

on:
  push:
    branches: [main]

env:
  REGISTRY: ghcr.io
  IMAGE_NAME: ${{ github.repository }}

jobs:
  build-and-push:
    runs-on: ubuntu-latest
    permissions:
      contents: read
      packages: write
    steps:
      - uses: actions/checkout@v4
      - uses: docker/login-action@v3
        with:
          registry: ${{ env.REGISTRY }}
          username: ${{ github.actor }}
          password: ${{ secrets.GITHUB_TOKEN }}
      - uses: docker/build-push-action@v6
        with:
          context: app
          push: true
          tags: ${{ env.REGISTRY }}/${{ env.IMAGE_NAME }}:${{ github.sha }},${{ env.REGISTRY }}/${{ env.IMAGE_NAME }}:latest

  deploy:
    needs: build-and-push
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: aws-actions/configure-aws-credentials@v4
        with:
          aws-access-key-id: ${{ secrets.AWS_ACCESS_KEY_ID }}
          aws-secret-access-key: ${{ secrets.AWS_SECRET_ACCESS_KEY }}
          aws-region: ap-south-1
      - name: Deploy to Amazon ECS
        run: |
          aws ecs update-service --cluster flask-cluster --service flask-service \
            --force-new-deployment
```


## Output
**output**

![output.png](screenshots/output.png)

**yaml check**

![yaml_check.png](screenshots/yaml_check.png)

## Screenshots you still need to capture yourself
- [ ] Screenshots of the green workflow run, the package in GHCR and the deployment.

Put them in `screenshots/` and add a line to this README so the GitHub repo shows them.
